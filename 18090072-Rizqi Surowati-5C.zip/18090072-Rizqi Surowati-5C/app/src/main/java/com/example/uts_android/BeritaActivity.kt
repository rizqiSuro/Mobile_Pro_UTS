package com.example.uts_android

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uts_android.adapter.ImageAdapter

class BeritaActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_berita)

        val imageList = listOf<Image>(
            Image(
                R.drawable.berita1,
                "Cegah Corona, Mendagri Keluarkan Aturan Protokoler Kesehatan dalam Pilkades",
                "Liputan6.com, Jakarta Menteri Dalam Negeri (Mendagri) Tito Karnavian meminta agar protokoler kesehatan menjadi prioitas dalam pelaksanaan pemilihan kepala desa (Pilkades), sehingga tidak menimbulkan klaster baru penularan Covid-19.\n" +
                        "\n" +
                        "Menurutnya Pilkada dapat menjadi tolok ukur penerapan prokes sebelum terselenggaranya Pilkades.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "    HomeNewsPolitik\n" +
                        "\n" +
                        "Cegah Corona, Mendagri Keluarkan Aturan Protokoler Kesehatan dalam Pilkades\n" +
                        "Liputan6.comLiputan6.com\n" +
                        "\n" +
                        "13 Nov 2020, 10:01 WIB\n" +
                        "FOTO: Mendagri dan DPR Bahas Penanganan Pandemi COVID-19\n" +
                        "Perbesar\n" +
                        "Menteri Dalam Negeri Tito Karnavian saat rapat kerja dengan Komisi II DPR di Kompleks Parlemen, Jakarta, Rabu (24/6/2020). Rapat membahas pendahuluan RAPBN TA 2021, rencana kerja pemerintah, serta upaya dan kinerja pemerintah daerah dalam menangani pandemi COVID-19. (Liputan6.com/Johan Tallo)\n" +
                        "\n" +
                        "Liputan6.com, Jakarta Menteri Dalam Negeri (Mendagri) Tito Karnavian meminta agar protokoler kesehatan menjadi prioitas dalam pelaksanaan pemilihan kepala desa (Pilkades), sehingga tidak menimbulkan klaster baru penularan Covid-19.\n" +
                        "\n" +
                        "Menurutnya Pilkada dapat menjadi tolok ukur penerapan prokes sebelum terselenggaranya Pilkades.\n" +
                        "\n" +

                        " "

            )

        )

        val recyclerView = findViewById<RecyclerView>(R.id._imageRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = ImageAdapter(this, imageList){
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}